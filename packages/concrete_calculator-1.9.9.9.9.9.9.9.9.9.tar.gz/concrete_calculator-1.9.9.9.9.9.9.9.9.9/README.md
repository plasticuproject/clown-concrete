A concrete volume calculator.

Usage:
```python
from calculator import *


unit_converter = UnitConverter()
calculator = RoundSlabConcreteCalculator(unit_converter)
calculator_data = ConcreteStructureData(diameter=10, depth=5)
volume = calculator.calculate_volume(calculator_data, units='ft')
volume
392.69908169872417
# Calculate round structure volume in cubic yards
round_volume_in_yards = round_slab_calculator.calculate_volume(diameter=10, depth=5, units='yd')

print(f"The volume of the round slab in cubic yards is: {round_volume_in_yards:.2f}")

# Calculate square structure volume in cubic feet
square_volume_in_feet = square_slab_calculator.calculate_volume(diameter=10, depth=5, units='ft')
