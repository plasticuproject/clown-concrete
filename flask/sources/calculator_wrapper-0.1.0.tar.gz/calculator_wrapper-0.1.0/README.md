A python wrapper for the concrete_calculator python library, to be used for calculating volumes of various square and round concrete structures.
