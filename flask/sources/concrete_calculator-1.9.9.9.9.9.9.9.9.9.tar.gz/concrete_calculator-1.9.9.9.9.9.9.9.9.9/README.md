Python library for calculating square and round concrete structure volumes.


